﻿using System;
using System.Drawing;

namespace ContraClone
{
	public class SpriteImage
	{
		int centerX;
		int centerY;

		public SpriteImage ()
		{
		}
	}
}

