﻿using System;

namespace ContraClone
{
	public class Physics
	{
		protected int Gravity;

		public Physics ()
		{
		}
	}
}

