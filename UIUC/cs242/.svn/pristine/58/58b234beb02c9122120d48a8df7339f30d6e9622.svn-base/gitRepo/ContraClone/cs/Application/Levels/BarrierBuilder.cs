﻿using System;
using System.Drawing;
using System.Reflection;

namespace ContraClone
{
	public static class BarrierBuilder
	{
		public static void barriorBuilder (ref sceneInfo info)
		{
			Image background = level1(ref info);

			info.hero = new Character (5, 5, "target");
			info.hero.scaleImage (15, 15);
			info.view_target = info.hero;

			Physics.initPysics ((int)timeEnum.CONTROL_REFRESH);

			info.objects [info.characterCount++] = info.hero;


			info.background = new Background (background, Init.window);
			info.background.calculatePosition (info.view_target);
			info.backgrounds [info.backgrounds.Length - 1] = info.background;
		}

		public static Image level1(ref sceneInfo info)
		{
			String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/level1.png";
			return (Bitmap)Image.FromFile (imagePath, true);
		}

		public static Image level2(ref sceneInfo info)
		{
			String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/level2.png";
			return (Bitmap)Image.FromFile (imagePath, true);
		}
	}
}

