﻿using System;
using System.Drawing;

namespace ContraClone
{
	public class Level2
	{
		public static void init(ref sceneInfo info)
		{
			staticProperties (ref info);
		}

		private static void staticProperties(ref sceneInfo info){
			String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/level2.png";
			Image background = (Bitmap)Image.FromFile (imagePath, true);

			info.hero = new Character (200, 0, "hero");
			info.view_target = info.hero;
			info.barrierTolerance = 25;
			info.hero.jumpForce = 60000;

			Physics.initPysics ((int)timeEnum.CONTROL_REFRESH);

			info.objects [info.characterCount++] = info.hero;

			info.levelCount = 7;
			info.barriers = new Barrier[info.levelCount] [];
			createBarriors (ref info);

			info.background = new Background (background, Init.window);
			//info.background.bottomOffset = 0;
			info.background.calculatePosition (info.view_target);
			info.backgrounds [info.backgrounds.Length - 1] = info.background;
		}

		private static void createBarriors(ref sceneInfo info)
		{
			info.barriers [0] = new Barrier[2];
			info.barriers [0] [info.barrierCounts[0]++] = new Barrier(7617, 339, 8197, 339, true, false, true, false);
			info.barriers [0] [info.barrierCounts[0]++] = new Barrier(8415, 339, 9647, 339, true, false, true, false);

			info.barriers [1] = new Barrier[2];
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(1459, 417, 2253, 417, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(947, 417, 1237, 417, true, false, true, false);

			info.barriers [2] = new Barrier[1];
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(2911, 457, 3125, 457, true, false, false, false);

			info.barriers [3] = new Barrier[2];
			info.barriers [3] [info.barrierCounts[3]++] = new Barrier(5953, 557, 6887, 557, true, false, true, false);
			info.barriers [3] [info.barrierCounts[3]++] = new Barrier(7255, 557, 7903, 557, true, false, true, false);

			info.barriers [4] = new Barrier[3];
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(659, 631, 1235, 631, true, false, false, false);
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(2035, 631, 2539, 631, true, false, false, false);
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(5153, 701, 5293, 701, true, false, false, false);

			info.barriers [5] = new Barrier[8];
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(9793, 777, 12821, 777, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(8343, 777, 8991, 777, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(6605, 777, 7613, 777, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(5519, 777, 5875, 777, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(4861, 777, 5007, 777, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(2545, 777, 3697, 777, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(1747, 777, 1889, 777, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(1383, 777, 1527, 777, true, false, false, false);

			info.barriers [6] = new Barrier[6];
			info.barriers [6] [info.barrierCounts[6]++] = new Barrier(81, 851, 657, 851, true, false, false, false);
			info.barriers [6] [info.barrierCounts[6]++] = new Barrier(3923, 851, 4857, 851, true, false, false, false);
			info.barriers [6] [info.barrierCounts[6]++] = new Barrier(5883, 851, 6601, 851, true, false, false, false);
			info.barriers [6] [info.barrierCounts[6]++] = new Barrier(7615, 851, 8195, 851, true, false, false, false);
			info.barriers [6] [info.barrierCounts[6]++] = new Barrier(9215, 851, 9571, 851, true, false, false, false);
			info.barriers [6] [info.barrierCounts[6]++] = new Barrier(9211, 851, 9571, 851, true, false, false, false);
		}	
	}
}

