﻿using System;

namespace ContraClone
{
	public class Weapon
	{
		protected Delegate firingPatturn;

		public Weapon ()
		{
			firingPatturn = singleShotDelegate();
		}

		public Delegate singleShotDelegate()
		{
			//TODO: Implement.
			return null;
		}

		public Delegate fanShotDelegate()
		{
			//TODO: Implement.
			return null;
		}
	}
}

