﻿using System;

namespace ContraClone
{
	public class HorzScrollingSprite
	{
		public HorzScrollingSprite ()
		{
		}
	}
}

