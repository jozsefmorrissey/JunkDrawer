﻿using System;

namespace ContraClone
{
	public class Ground : Sprite
	{
		protected int length;
		protected int width;
		protected bool water;

		public Ground ()
		{
		}

		public override void calculatePosition (SceneObject focalPoint)
		{

		}
	}
}

