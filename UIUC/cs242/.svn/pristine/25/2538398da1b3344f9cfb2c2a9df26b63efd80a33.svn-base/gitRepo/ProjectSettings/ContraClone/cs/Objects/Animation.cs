﻿using System;
using System.Drawing;

namespace ContraClone
{
	public class Animation
	{
		protected SpriteImage[] idleImages;
		protected SpriteImage[] walkImages;
		protected SpriteImage[] jumpImages;
		protected SpriteImage[] crouchImages;
		protected SpriteImage[] deadImages;

		public Animation (String characterFileName)
		{
			
		}

		protected void addSprites(SpriteImage[] arrayImages, String fileNamePrefix){
			bool spriteFound = true;
			String fileNameSuffix = ".png";
			while (spriteFound) 
			{
				//TODO: create standardized file name system and automate image import.
			}
		}
	}
}

