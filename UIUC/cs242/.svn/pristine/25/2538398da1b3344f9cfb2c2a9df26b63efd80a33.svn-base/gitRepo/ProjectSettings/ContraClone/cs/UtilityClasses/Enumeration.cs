﻿using System;

namespace ContraClone
{
	public enum animEnum
	{
		IDLE, WALK, JUMP, CROUCH, DIE, FALL
	}

	public enum charEnum
	{
		GROUNDED, MOVING, DEAD
	}

	public enum keyEnum
	{
		RIGHT = 0,
		LEFT = 1,
		UP = 2,
		DOWN = 3,
		SPACE = 4,
	}
}

