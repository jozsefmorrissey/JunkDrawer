﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ContraClone
{
	public class Background : SceneObject
	{
		public int endOfMap;
		public int bottomOffset = 18;
		protected int topOffset;
		protected Bitmap image;
		protected Bitmap currentBackground;
		protected Window window;

		public Background (Image img, Window win)
		{
			double scale = (double)win.Height / (double)img.Height;
			image = new Bitmap(img, new Size((int)(img.Width*scale), (int)(img.Height*scale)));			
			window = win;
			layer = 0;
			visible = true;
		}

		public void resize()
		{
			float height = image.Height - bottomOffset;	

			double scale = (double)window.Height / (double)height;
			image = new Bitmap (image, new Size ((int)(image.Width * scale), (int)(height * scale + bottomOffset*scale)));
		}

		public override void calculatePosition (SceneObject focalPoint)
		{


			lastX = focalPoint.phyStruct.positionX;
			endOfMap = image.Width;

			float height = image.Height - bottomOffset;	
			double scale = (double)window.Height / (double)height;

			if(currentBackground != null)
				currentBackground.Dispose ();
			Rectangle cropSection = Utilities.determineCropedSection (image.Width, (int)(image.Height - bottomOffset*scale), window.Width, focalPoint.phyStruct.positionX);
			currentBackground = image.Clone (cropSection, image.PixelFormat);

			window.BackgroundImage = currentBackground;
			//clip.Dispose ();
		}


			
		protected bool update_bacground (SceneObject focalPoint)	
		{
			if (lastX < focalPoint.phyStruct.positionX - refreshDist || lastX > focalPoint.phyStruct.positionX + refreshDist)
				return true;
			return false;
		}
	}
}

