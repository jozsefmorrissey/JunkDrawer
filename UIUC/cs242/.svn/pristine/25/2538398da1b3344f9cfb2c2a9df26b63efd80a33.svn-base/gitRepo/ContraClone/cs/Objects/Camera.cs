﻿using System;

namespace ContraClone
{
	public class Camera
	{
		public int x;

		public Camera ()
		{
		}

		public void move (SceneObject target)
		{

		}
	}
}

