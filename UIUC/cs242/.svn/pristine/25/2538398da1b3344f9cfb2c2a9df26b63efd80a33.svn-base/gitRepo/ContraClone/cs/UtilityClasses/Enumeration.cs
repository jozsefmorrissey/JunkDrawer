﻿using System;

namespace ContraClone
{
	public enum animEnum
	{
		IDLE = 0, WALK = 1, JUMP = 2, CROUCH = 3, DIE = 4, FALL = 5, LAND = 6, TUCK = 7
	}

	public enum charEnum
	{
		GROUNDED, MOVING, DEAD
	}

	public enum keyEnum
	{
		RIGHT = 0,
		LEFT = 1,
		UP = 2,
		DOWN = 3,
		SPACE = 4,
		ENTER = 5,
		A = 6,
		D = 7,
		P = 8,
		C = 9,
		W = 10,
		G = 11,
		B = 12,
		L = 13,
		K = 14,
		X = 15,
		S = 16,
	}

	public enum timeEnum
	{
		CONTROL_REFRESH = 20,
		BARRIOR_BUILD_REFRESH = 500,
	}
}

