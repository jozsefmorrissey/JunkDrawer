﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace ContraClone
{
	public class Character : SceneObject
	{
		protected bool alive;
		protected int Damage;
		public Barrier currentPlatform;
		protected int Health;
		protected Weapon weapon;
		protected Animation anim;
		public Image image;
		protected int refreshRate;
		protected int refCount = 0;

		public Character ()
		{
		}

		public Character(int startx, int starty, String imageName)
		{
			//String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/cropped_contra_images/hero/idle1.png";
			String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/" + imageName + ".png";
			image = (Bitmap)Image.FromFile (imagePath, true);
			image = Utilities.ScaleImage (image, 75, 75);
			staticX = Init.window.Width / 2 - image.Width;
			staticY = Init.window.Height / 2 - image.Height;

			refreshRate = 10;

			centerX = image.Width / 2;
			centerY = image.Height / 2;

			anim = new Animation ("hero/", 75, 10000);

			phyStruct.positionX = startx;
			phyStruct.positionY = starty;
			phyStruct.mass = 80;
			phyStruct.velocityX = phyStruct.velocityY = phyStruct.forceX = phyStruct.forceY = 0;
		}

		public override void calculatePosition (SceneObject focalPoint)
		{

		}

		public void paint(Graphics formGraphics)
		{
			//if (refCount++ % refreshRate == 0)
			//	this.image = anim.updateAnim (animEnum.WALK).image;
			if(Init.scene.info.view_target.phyStruct.positionX >= Init.scene.info.background.endOfMap - Init.window.Width / 2)
			{
				staticX = (int)Init.scene.info.view_target.phyStruct.positionX - Init.scene.info.background.endOfMap + Init.window.Width;
			}
			else if (Init.scene.info.view_target.phyStruct.positionX > Init.window.Width / 2) 
			{
				staticX = Init.window.Width / 2;
			} 
			else 
			{
				staticX = (int)this.phyStruct.positionX;
			}
								
			formGraphics.DrawImage (image, staticX, (int)this.phyStruct.positionY);
		}

		public bool move(int rightLeft, int upDown)
		{
			this.phyStruct.positionX += rightLeft;
			this.phyStruct.positionY += upDown;


			if (this.phyStruct.positionX < image.Width / 2)
				this.phyStruct.positionX = image.Width / 2;
			if (this.phyStruct.positionX > Init.scene.info.background.endOfMap - image.Width / 2)
				this.phyStruct.positionX = Init.scene.info.background.endOfMap - image.Width / 2;

			lastX = this.phyStruct.positionX;
			lastY = this.phyStruct.positionY;
		
				return false;
		}

		public int getHeight(){return image.Height;}
	
		public double getCenterBottom(){
			return this.phyStruct.positionX + this.centerX;
		}

		public void scaleImage (int width, int height){
			image = Utilities.ScaleImage (image, width, height);
		}
	}
}