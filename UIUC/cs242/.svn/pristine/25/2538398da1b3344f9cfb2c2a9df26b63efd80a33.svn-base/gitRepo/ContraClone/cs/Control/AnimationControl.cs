﻿using System;

namespace ContraClone
{
	public class AnimationControl
	{
		public AnimationControl ()
		{
		}

		//TODO: develop transitions functions based on position, velocity, barrior_contact
		public void transitioinFunction()
		{

		}
	}
}

