﻿using System;
using System.Drawing;

namespace ContraClone
{
	public class Level1
	{
		//public abstract class BarriorBuilder{};

		public static void init(ref sceneInfo info)
		{
			staticProperties (ref info);
		}

		private static void staticProperties(ref sceneInfo info){
			String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/level1.png";
			Image background = (Bitmap)Image.FromFile (imagePath, true);

			info.hero = new Character (200, 0, "hero");
			info.view_target = info.hero;
			info.barrierTolerance = 15;
			info.hero.jumpForce = 50000;

			Physics.initPysics ((int)timeEnum.CONTROL_REFRESH);

			info.objects [info.characterCount++] = info.hero;

			info.levelCount = 7;
			info.barriers = new Barrier[info.levelCount] [];
			createBarriors (ref info);

			info.background = new Background (background, Init.window);
			info.background.calculatePosition (info.view_target);
			info.backgrounds [info.backgrounds.Length - 1] = info.background;
		}
	
		private static void createBarriors(ref sceneInfo info)
		{
			info.barriers [0] = new Barrier[3];
			info.barriers [0] [info.barrierCounts[0]++] = new Barrier(5390, 295, 7395, 295, true, false, true, false);
			info.barriers [0] [info.barrierCounts[0]++] = new Barrier(8020, 295, 8650, 295, true, false, true, false);
			info.barriers [0] [info.barrierCounts[0]++] = new Barrier(10280, 295, 10530, 295, true, false, true, false);

			info.barriers [1] = new Barrier [18];
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(12290, 420, 12790, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(10660, 420, 10910, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(10155, 420, 10405, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(9280, 420, 9525, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(8775, 420, 9025, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(7275, 420, 8150, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(4635, 420, 5640, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(4510, 420, 4635, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(4385, 420, 4510, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(4260, 420, 4385, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(4130, 420, 4260, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(3505, 420, 4130, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(3380, 420, 3505, 420, true, false, false, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(3380, 420, 3505, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(3260, 420, 3380, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(3130, 420, 3260, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(3000, 420, 3130, 420, true, false, true, false);
			info.barriers [1] [info.barrierCounts[1]++] = new Barrier(115, 420, 3000, 420, true, false, true, false);

			info.barriers [2] = new Barrier [9];
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(620, 545, 995, 545, true, false, true, false);
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(1625, 545, 1870, 545, true, false, true, false);
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(6263, 547, 7139, 547, true, false, true, false);
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(8525, 545, 8900, 545, true, false, true, false);
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(9155, 545, 9405, 545, true, false, true, false);
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(9655, 545, 9905, 545, true, false, true, false);
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(10785, 545, 11410, 545, true, false, true, false);
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(12040, 545, 12285, 545, true, false, true, false);
			info.barriers [2] [info.barrierCounts[2]++] = new Barrier(12790, 545, 12915, 545, true, false, true, false);

			info.barriers [3] = new Barrier [5];
			info.barriers [3] [info.barrierCounts[3]++] = new Barrier(12415, 610, 12790, 610, true, false, true, false);
			info.barriers [3] [info.barrierCounts[3]++] = new Barrier(10410, 610, 10530, 610, true, false, true, false);
			info.barriers [3] [info.barrierCounts[3]++] = new Barrier(8275, 610, 8400, 610, true, false, true, false);
			info.barriers [3] [info.barrierCounts[3]++] = new Barrier(5890, 610, 6140, 610, true, false, true, false);
			info.barriers [3] [info.barrierCounts[3]++] = new Barrier(2500, 610, 2875, 610, true, false, true, false);

			info.barriers [4] = new Barrier [7];
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(995, 675, 1120, 675, true, false, true, false);
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(1375, 675, 1495, 675, true, false, true, false);
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(7520, 675, 7775, 675, true, false, false, false);
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(7900, 675, 8150, 675, true, false, false, false);
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(9780, 675, 10155, 675, true, false, false, false);
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(11660, 675, 11910, 675, true, false, false, false);
			info.barriers [4] [info.barrierCounts[4]++] = new Barrier(12915, 675, 13040, 675, true, false, true, false);

			info.barriers [5] = new Barrier [10];
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(12290, 800, 13528, 800, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(11163, 800, 11533, 800, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(10283, 800, 10408, 800, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(9658, 800, 9778, 800, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(9151, 795, 9275, 795, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(6773, 800, 7523, 800, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(5518, 800, 5888, 800, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(2378, 800, 2623, 800, true, false, false, false);
			info.barriers [5] [info.barrierCounts[5]++] = new Barrier(1123, 800, 1368, 800, true, false, false, false);

			info.barriers [6] = new Barrier [6];
			info.barriers [6] [info.barrierCounts[6]++] = new Barrier(5, 840, 6935, 840, true, true, false, false);
		}	
	}
}

