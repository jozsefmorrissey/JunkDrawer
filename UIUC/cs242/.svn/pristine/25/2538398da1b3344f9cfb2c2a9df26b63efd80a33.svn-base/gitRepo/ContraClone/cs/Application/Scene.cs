﻿using System;
using System.Windows.Forms;
using System.Drawing;


namespace ContraClone
{
	public struct sceneInfo{
		public Character[] objects;
		public System.Windows.Forms.Timer time;
		public SceneObject view_target;
		public Character hero;
		public Window window;
		public Background[] backgrounds;
		public Barrier[][] barriers;
		public int levelCount;
		public int[] barrierCounts;
		public Background background;
		public int characterCount;
		public int barrierTolerance;
		public int barrierCount;
		public Barrier [] inactiveNeedsReset;
		public int resetCount;
	}

	public class Scene
	{
		public sceneInfo info;

		public Scene (Window win)
		{
			info = new sceneInfo ();
			info.window = win;
			info.backgrounds = new Background[5];
			info.objects = new Character[20];
			info.characterCount = 0;
			info.barrierCounts = new int[7];
			info.inactiveNeedsReset = new Barrier [5];
			info.resetCount = 0;
			if (Init.barriorBuilder)
				BarrierBuilder.barriorBuilder (ref info);
			else
				Level1.init (ref info);
		}
			
		public void paint(Graphics graphics)
		{
			//TODO: Create loops that update all objects present in the scene.
			//bkgd.paint_background (graphics, hero);
			info.hero.paint (graphics);
		}

		public void updateGraphics(int rightLeft, int upDown)
		{
			info.hero.phyStruct.forceX += rightLeft * info.hero.horizontalVelocity;
			if(info.hero.currentPlatform != null)
				info.hero.phyStruct.forceY += upDown * info.hero.jumpForce;
			if (upDown != 0)
				info.hero.currentPlatform = null;

			if (info.hero.currentPlatform != null && (info.hero.getCenterBottom () > info.hero.currentPlatform.getEndX () || info.hero.getCenterBottom () < info.hero.currentPlatform.getStartX ()))
				info.hero.currentPlatform = null;
			//info.hero.move (rightLeft, upDown);
			//view_target.move (hero.x);
			info.background.calculatePosition (info.view_target);
			//Init.window.Invalidate ();
		}

		public void updateGraphicsBuilder(int rightLeft, int upDown)
		{
			info.hero.phyStruct.positionX += rightLeft;
			info.hero.phyStruct.positionY += upDown;
			//view_target.move (hero.x);
			info.background.calculatePosition (info.view_target);
			Init.window.Invalidate ();
		}

		public void dropDown(){
			Barrier platform = this.info.hero.currentPlatform;
			if (platform != null && platform.getCanDrop ()) {
				platform.setActive (false);
				this.info.hero.currentPlatform = null;
				info.inactiveNeedsReset [info.resetCount++] = platform;
			}
		}


		public void gravity()
		{
			for (int index = 0; index < info.characterCount; index++) 
			{
				if (info.objects [index] != null && info.objects [index].currentPlatform == null && info.objects [index].phyStruct.velocityY > 0) {
					findPlatform (ref info.objects [index]);
					//info.objects [index].phyStruct.positionY += 10;
					//info.objects [index].phyStruct = Physics.calculateFinalPosition (info.objects [index].phyStruct, false);
					//Physics.calculateFinalPositionVertical
				}
			}
		}

		public void findPlatform(ref Character sprite)
		{
			for (int index = 0; index < info.levelCount; index++) 
			{
				double bottomOfSprite = sprite.phyStruct.positionY + sprite.getHeight ();
				Barrier[] barrior = info.barriers [index];
				if (barrior[0].getStartY () - info.barrierTolerance <= bottomOfSprite && barrior[0].getStartY () + info.barrierTolerance >= bottomOfSprite){
					for (int barriorIndex = 0; barriorIndex < info.barrierCounts [index]; barriorIndex++) {
						if (sprite.getCenterBottom () >= barrior [barriorIndex].getStartX () && sprite.getCenterBottom () <= barrior [barriorIndex].getEndX () &&  barrior [barriorIndex].getActive ()) {
							sprite.phyStruct.positionY = barrior [barriorIndex].getEndY () - sprite.getHeight ();
							sprite.currentPlatform = barrior [barriorIndex];
							sprite.phyStruct.velocityY = sprite.phyStruct.forceY = 0;
							resetPlatforms ();
						}
					}
				}
			}
		}

		private void resetPlatforms()
		{
			if(info.resetCount > 0){
				for(int index = 0; index < info.resetCount; index++){
					info.inactiveNeedsReset[index].setActive (true);
				}
			}
			info.resetCount = 0;
		}
	}

}

