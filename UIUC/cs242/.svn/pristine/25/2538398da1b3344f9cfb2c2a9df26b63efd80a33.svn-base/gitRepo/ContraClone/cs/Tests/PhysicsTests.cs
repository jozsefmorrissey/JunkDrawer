﻿using System;
using System.Threading;

namespace ContraClone
{
	public static class PhysicsTests
	{

		public static void TestGravity(){
			Physics.initPysics (50);
			physicsSturct testPhysics = new physicsSturct ();

			testPhysics.forceY = -10000;
			testPhysics.velocityY = 0;
			testPhysics.positionY = 0;
			testPhysics.mass = 80;
			int count = 0;
			double vnot = 0;
			while (count < 20000) {
				testPhysics = Physics.calculateFinalPosition (testPhysics, false);
				testPhysics.forceY = 0;
				count++;
				vnot += ((1.0 / 20.0) * 9.8);
				if (count % 5 == 0) {
					System.Console.WriteLine ("itteration: " + (count / 20) + ": " + testPhysics.velocityY + "," + testPhysics.positionY + "," + testPhysics.forceY);
					System.Console.WriteLine ("reg: " + vnot);
					//Thread.Sleep (200);
				}
			}
		}
		public static void testHorizontalMovementPhysics(){
			Physics.initPysics (50);
			physicsSturct testPhysics = new physicsSturct ();

			testPhysics.forceX = 400;
			testPhysics.velocityX = 0;
			testPhysics.positionX = 0;
			testPhysics.mass = 80;
			int count = 0;
			double vnot = 0;
			while (count < 20000) {
				testPhysics = Physics.calculateFinalPosition (testPhysics, true);
				testPhysics.forceX = 400;
				count++;
				vnot += ((1.0 / 20.0) * 9.8);
				if (count % 20 == 0) {
					System.Console.WriteLine ("itteration: " + (count / 20) + ": " + testPhysics.velocityX + "," + testPhysics.positionX + "," + testPhysics.forceX);
					System.Console.WriteLine ("reg: " + vnot);
					//Thread.Sleep (200);
				}
			}
		}
	}
}

