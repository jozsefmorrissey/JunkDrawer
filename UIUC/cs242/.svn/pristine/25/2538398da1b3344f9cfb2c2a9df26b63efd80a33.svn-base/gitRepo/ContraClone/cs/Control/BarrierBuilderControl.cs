﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;

namespace ContraClone
{
	public class BarrierBuilderControl : Control
	{

		private static int barriorStartX = 0;
		private static int barriorStartY = 0;
		private static int barriorEndX = 0;
		private static int barriorEndY = 0;
		private static int barriorPointCount = 0;
		private static int barriorLevel = 0;
		private static string ground;
		private static string water;
		private static string canDrop;
		private static string wall;

		public BarrierBuilderControl()
		{
			keys = new []{Keys.Right, Keys.Left, Keys.Up, Keys.Down, Keys.Space, Keys.Enter, 
				Keys.A, Keys.D, Keys.P, Keys.C, Keys.W, Keys.G, Keys.B, Keys.L, Keys.K, Keys.X, Keys.S};
			ground = "false";
			water = "false";
			canDrop = "false";
			wall = "false";
			keysDown = new bool[keys.Length];
			keysProcessed = new bool[keysDown.Length];
		}
			
		//TODO: Figure out a non-delayed key detection method.
		// Detect all keys used during game play.
		protected override void gamePlayKeyPress(int keyIndex)
		{
			int movementOffset = 2;
			switch (keyIndex)
			{
			case (int)keyEnum.RIGHT:
				Init.scene.updateGraphicsBuilder (movementOffset, 0);
				break;
			case (int)keyEnum.LEFT:
				Init.scene.updateGraphicsBuilder (-movementOffset, 0);
				break;
			case (int)keyEnum.UP:
				Init.scene.updateGraphicsBuilder (0, -movementOffset);
				break;
			case (int)keyEnum.DOWN:
				Init.scene.updateGraphicsBuilder (0, movementOffset);
				break;
			case (int)keyEnum.SPACE:
				Init.scene.updateGraphics (0, -movementOffset);
				break;
			}

			addBarriorControls (keyIndex, movementOffset);
		}

		private static void addBarriorControls(int keyIndex, int movementOffset)
		{
			switch (keyIndex) {
			case (int)keyEnum.ENTER:
				if (!keysProcessed[(int)keyEnum.ENTER]){
					Character hero = Init.scene.info.hero;
					if (barriorPointCount % 2 == 0 && (barriorEndX != hero.phyStruct.positionX || barriorEndY != hero.phyStruct.positionY)) {
						barriorStartX = (int)hero.phyStruct.positionX;
						barriorStartY = (int)hero.phyStruct.positionY;
						barriorPointCount++;
					} else if(barriorStartX != hero.phyStruct.positionX || barriorStartY != hero.phyStruct.positionY){
						barriorEndX = (int)hero.phyStruct.positionX;
						barriorEndY = (int)hero.phyStruct.positionY;
						barriorPointCount++;
					}
					keysProcessed [(int)keyEnum.ENTER] = true;
				}
				break;
			case (int)keyEnum.A:
				Init.scene.updateGraphicsBuilder (20 * -movementOffset, 0);
				break;
			case (int)keyEnum.D:
				Init.scene.updateGraphicsBuilder (20 * movementOffset, 0);
				break;
			case (int)keyEnum.X:
				Init.scene.updateGraphicsBuilder (0, 20 * movementOffset);
				break;
			case (int)keyEnum.S:
				Init.scene.updateGraphicsBuilder (0, 20 * -movementOffset);
				break;
			case (int)keyEnum.C:
				changeDeterministicKeys (ref keysProcessed [(int)keyEnum.C], ref canDrop);
				break;
			case (int)keyEnum.G:
				changeDeterministicKeys (ref keysProcessed [(int)keyEnum.G], ref ground);
				break;
			case (int)keyEnum.W:
				changeDeterministicKeys (ref keysProcessed [(int)keyEnum.W], ref water);
				break;
			case (int)keyEnum.B:
				changeDeterministicKeys (ref keysProcessed [(int)keyEnum.B], ref wall);
				break;
			case (int)keyEnum.L:
				if (!keysProcessed[(int)keyEnum.L]){
					barriorLevel++;
					keysProcessed [(int)keyEnum.L] = true;
				}
				break;
			case(int)keyEnum.K:
				if (!keysProcessed [(int)keyEnum.K]) {
					barriorLevel--;
					keysProcessed [(int)keyEnum.K] = true;
				}
				break;
			case (int)keyEnum.P:
				if (!keysProcessed [(int)keyEnum.P]) {
					string addBarriorPrefix = "info.barriers [" + barriorLevel + "] [info.barrierCounts[" + barriorLevel + "]++] = new Barrier(";
					string locatioinArguments;
					if (barriorEndX <= barriorStartX && barriorEndY <= barriorStartY)
						locatioinArguments = barriorEndX + ", " + barriorEndY + ", " + barriorStartX + ", " + barriorStartY + ", ";
					else if (barriorEndX >= barriorStartX && barriorEndY >= barriorStartY)
						locatioinArguments = barriorStartX + ", " + barriorStartY + ", " + barriorEndX + ", " + barriorEndY + ", ";
					else
						locatioinArguments = " ERROR invalid coordinates ";

					string typeArguments = ground + ", " + water + ", " + canDrop + ", " + wall + ");";
					System.Console.WriteLine (addBarriorPrefix + locatioinArguments + typeArguments);
					//Thread.Sleep (10000);
					wall = "false";
					water = "false";
					canDrop = "false";
					ground = "false";
					keysProcessed [(int)keyEnum.P] = true;
				}
				break;
			}
			displayBarriorState ();
		}

		private static void displayBarriorState(){
			string point1;
			string point2;
			if (barriorEndX <= barriorStartX && barriorEndY <= barriorStartY) {
				point1 = "(" + barriorEndX + ", " + barriorEndY + ")";
				point2 = "(" + barriorStartX + ", " + barriorStartY + ")";
			} else if (barriorEndX >= barriorStartX && barriorEndY >= barriorStartY) {
				point1 = "(" + barriorStartX + ", " + barriorStartY + ")";
				point2 = "(" + barriorEndX + ", " + barriorEndY + ")";
			} else {
				int temp = barriorEndY;
				barriorEndY = barriorStartY;
				barriorStartY = temp;
				if (barriorEndX <= barriorStartX && barriorEndY <= barriorStartY) {
					point1 = "(" + barriorEndX + ", " + barriorEndY + ")";
					point2 = "(" + barriorStartX + ", " + barriorStartY + ")";
				} else {
					point1 = "(" + barriorStartX + ", " + barriorStartY + ")";
					point2 = "(" + barriorEndX + ", " + barriorEndY + ")";
				}
			}

			string type = "";
			if (water == "true")
				type += "    water";
			if (ground == "true")
				type += "    ground";
			if (canDrop == "true")
				type += "    can drop";
			if (wall == "true")
				type += "    wall";

			Init.window.Text = "startPoint: " + point1 + "\tendPoint: " + point2 + "    Level: " + barriorLevel + type;
		}

		private static void changeDeterministicKeys(ref bool processed, ref string strBool)
		{
			if(!processed)
			{
				if (strBool == "true")
					strBool = "false";
				else
					strBool = "true";
				processed = true;
				//System.Console.WriteLine ("keyprocessed: " + strBool);
			}
		}
	}
}


