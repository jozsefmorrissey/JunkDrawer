using System;
using System.Windows.Forms;
using System.Drawing;
//using Gtk;




namespace ContraClone
{
	public static class Init
	{
		public static Window window;
		public static Scene scene;

		private static bool tests = true;
		public static bool barriorBuilder = false;

		static int Main(string[] args)
		{
			if (tests) {
				runTests();
				return 0;
			}
			
			window = new Window ();
			scene = new Scene (window);

			// Display the form as a modal dialog box.
			Application.Run(window);
			//window.Show();
			return 0;
		}

		private static void runTests()
		{
			//PhysicsTests.TestGravity();
			//PhysicsTests.testHorizontalMovementPhysics();
			TestClass.testAll ();
			AnimationTests.loadImages();
		}
	}
}
