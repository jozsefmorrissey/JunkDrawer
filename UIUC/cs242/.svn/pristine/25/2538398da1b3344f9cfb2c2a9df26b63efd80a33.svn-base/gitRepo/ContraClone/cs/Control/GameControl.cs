﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;


namespace ContraClone
{
	public class GameControl : Control
	{
		private static double savedX;
		private static double savedY;

		//TODO: Figure out a non-delayed key detection method.
		// Detect all keys used during game play.
		protected override void gamePlayKeyPress(int keyIndex)
		{
			int movementOffset = 1;
			switch (keyIndex)
			{
				case (int)keyEnum.RIGHT:
					Init.scene.updateGraphics (movementOffset, 0);
					break;
				case (int)keyEnum.LEFT:
					Init.scene.updateGraphics (-movementOffset, 0);
					break;
				case (int)keyEnum.UP:
				Init.scene.updateGraphics (0, -movementOffset);
					break;
				case (int)keyEnum.DOWN:
					Init.scene.dropDown();
					break;
				case (int)keyEnum.SPACE:
				Init.scene.updateGraphics (0, -movementOffset);
					break;
				case (int)keyEnum.ENTER:
					savedX = Init.scene.info.view_target.phyStruct.positionX;
					savedY = Init.scene.info.view_target.phyStruct.positionY;
					break;
			case (int)keyEnum.A:
				Init.scene.info.view_target.phyStruct.positionX = savedX;
				Init.scene.info.view_target.phyStruct.positionY = savedY;
				Init.scene.info.view_target.setPhyStruct (savedX, savedY, 0, 0);
				Init.scene.info.hero.currentPlatform = new Barrier (0,0,0,0);
					break;
			}
		}
	}
}

