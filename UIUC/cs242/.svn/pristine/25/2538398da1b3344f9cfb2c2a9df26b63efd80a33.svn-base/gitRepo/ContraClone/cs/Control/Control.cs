﻿using System;
using System.Windows.Forms;

namespace ContraClone
{
	public abstract class Control
	{
		protected static bool[] keysDown;
		protected static Keys[] keys;
		protected static bool[] keysProcessed;

		protected abstract void gamePlayKeyPress(int index);

		public Control()
		{
			keys = new []{Keys.Right, Keys.Left, Keys.Up, Keys.Down, Keys.Space, Keys.Enter, Keys.L};
			keysDown = new bool[keys.Length];
			keysProcessed = new bool[keysDown.Length];
		}

		public void keyTimerCallback(object sender, EventArgs e)
		{
			for (int index = 0; index < keysDown.Length; index++) 
			{
				if (keysDown [index]) 
				{
					gamePlayKeyPress (index);
				}
			}
			if (!Init.barriorBuilder) {
				Init.scene.info.hero.phyStruct = Physics.calculateFinalPosition (Init.scene.info.hero.phyStruct, Init.scene.info.hero.currentPlatform != null);
				Init.scene.gravity ();
				Init.window.Invalidate ();
			}
		}

		public void keyDownEvent(object sender, KeyEventArgs e)
		{

			for (int index = 0; index < keysDown.Length; index++)
			{
				if(e.KeyCode == keys[index])
				{
					keysDown[index] = true;
				}
			}
		}

		public void keyUpEvent(object sender, KeyEventArgs e)
		{
			for (int index = 0; index < keysDown.Length; index++)
			{
				if(e.KeyCode == keys[index])
				{
					keysDown[index] = false;
					keysProcessed [index] = false;
				}
			}
		}
	}
}

