using System


static int Main(string[] args)
{
	//... 
	return 0;
}