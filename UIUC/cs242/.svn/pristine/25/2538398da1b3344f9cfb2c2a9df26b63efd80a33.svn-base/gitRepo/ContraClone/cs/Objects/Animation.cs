﻿using System;
using System.Drawing;
using System.Threading;

namespace ContraClone
{
	public class Animation
	{
		protected SpriteImage[] idleImages;
		protected SpriteImage[] runImages;
		protected SpriteImage[] jumpImages;
		protected SpriteImage[] landImages;
		protected SpriteImage[] tuckImages;
		protected SpriteImage[] crouchImages;
		protected SpriteImage[] deadImages;
		protected int idleCount, runCount, jumpCount, landCount, tuckCount, crouchCount, deadCount;
		protected int index;
		protected animEnum state;
		protected int scaleX;
		protected int scaleY;

		public Animation (String characterFileName, int sX, int sY)
		{
			index = idleCount = runCount = jumpCount = landCount = tuckCount = crouchCount = deadCount = 0;
			state = animEnum.IDLE;	
			scaleX = sX;
			scaleY = sY;
			characterFileName += "/";
			runImages = new SpriteImage[10];
			addSprites (ref runImages, ref runCount, characterFileName + "run");	
			jumpImages = new SpriteImage[10];
			addSprites (ref jumpImages, ref jumpCount, characterFileName + "jump");
			landImages = new SpriteImage[10];
			addSprites (ref landImages, ref landCount, characterFileName + "land");
			tuckImages = new SpriteImage[10];
			addSprites (ref tuckImages, ref tuckCount, characterFileName + "tuck");
			idleImages = new SpriteImage[10];
			addSprites (ref idleImages, ref idleCount, characterFileName + "idle");
			crouchImages = new SpriteImage[10];
			addSprites (ref crouchImages, ref crouchCount, characterFileName + "crouch");
			deadImages = new SpriteImage[10];
			addSprites (ref deadImages, ref deadCount, characterFileName + "dead");


		}

		protected void addSprites(ref SpriteImage[] arrayImages, ref int count, String fileNamePrefix)
		{
			bool spriteFound = true;
			while (spriteFound) 
			{
				//TODO: create standardized file name system and automate image import.
				String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/cropped_contra_images/" + fileNamePrefix + (count + 1) + ".png";
				try
				{
					Image image = Image.FromFile (imagePath, true);
					image = Utilities.ScaleImage (image, 75, 75);
					arrayImages [count] = new SpriteImage (image);
					count++;
				}
				catch 
				{
					spriteFound = false;
				}
			}
			count--;
		}

		public SpriteImage updateAnim(animEnum state)
		{
			if ((int)this.state != (int)state) 
			{
				index = 0;
				this.state = state;
			}

			switch ((int)state) 
			{
				case (int)animEnum.WALK:
					if (index > runCount)
						index = 0;
					return runImages [index++];

				case (int)animEnum.JUMP:
					if (index > jumpCount)
						index = 0;
					return jumpImages [index++];

				case (int)animEnum.LAND:
					if (index > landCount)
						index = 0;
					return landImages [index++];
			
			case (int)animEnum.TUCK:
				if (index > tuckCount)
					index = 0;
					return tuckImages [index++];

				case (int)animEnum.CROUCH:
					if (index > crouchCount)
						index = 0;
					return crouchImages [index++];

				case (int)animEnum.DIE:
					if (index > deadCount)
						index = 0;
					return deadImages [index++];

			case (int)animEnum.IDLE:
				if (index > idleCount)
					index = 0;
				return idleImages [index++];
			}

			return null;
		}
	}
}

