﻿using System;
using System.Drawing;
using System.Reflection;

namespace ContraClone
{
	public static class BarriorBuilder
	{
		public static void barriorBuilder (ref sceneInfo info)
		{
			level1(ref info);
		}

		public static void level1(ref sceneInfo info)
		{
			String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/level1.png";
			Image background = (Bitmap)Image.FromFile (imagePath, true);

			info.hero = new Character (5, 5, "target");
			info.hero.scaleImage (15, 15);
			info.view_target = info.hero;

			Physics.initPysics ((int)timeEnum.CONTROL_REFRESH);

			info.objects [info.characterCount++] = info.hero;


			info.background = new Background (background, Init.window);
			info.background.calculatePosition (info.view_target);
			info.backgrounds [info.backgrounds.Length - 1] = info.background;
		}
	}
}

