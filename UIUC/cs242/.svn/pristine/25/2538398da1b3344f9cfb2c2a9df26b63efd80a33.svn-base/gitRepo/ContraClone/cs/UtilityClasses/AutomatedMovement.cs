﻿using System;

namespace ContraClone
{
	public static class AutomatedMovement
	{
		public static void nonFiringRunners()
		{
			//TODO: Implement.
		}

		public static void firingRunners()
		{
			//TODO: Implement.
		}

		public static void staticFiring()
		{
			//TODO: Implement.
		}

		public static void staticObstacles()
		{
			//TODO: Implement.
		}
	}
}

