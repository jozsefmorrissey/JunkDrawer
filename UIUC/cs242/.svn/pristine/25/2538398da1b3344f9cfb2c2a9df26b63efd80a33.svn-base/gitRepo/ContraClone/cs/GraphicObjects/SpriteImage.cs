﻿using System;
using System.Drawing;

namespace ContraClone
{
	public class SpriteImage
	{
		public int centerX;
		public int centerY;
		public Image image;

		public SpriteImage (Image img)
		{
			image = img;
			centerX = (int)(img.Width / 2);
			centerY = (int)(img.Height / 2);
		}
	}
}

