﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace ContraClone
{
	public static class AnimationTests
	{
		public static Timer refreshTimer;
		public static Timer stateTimer;
		public static Form animDisplay;
		public static Animation anim;
		private static animEnum state = animEnum.WALK;

		public static void loadImages()
		{
			refreshTimer = new System.Windows.Forms.Timer ();
			refreshTimer.Interval = 75;
			refreshTimer.Tick += updateImage;
			refreshTimer.Start ();

			stateTimer = new System.Windows.Forms.Timer ();
			stateTimer.Interval = 2000;
			stateTimer.Tick += updateState;
			stateTimer.Start ();

			animDisplay = new Form ();
			anim = new Animation ("hero/");

			animDisplay.Height = 300;
			animDisplay.Width = 300;
			Graphics g = animDisplay.CreateGraphics ();
			g.DrawImage(anim.updateAnim(animEnum.WALK).image, 0 ,0);
			animDisplay.Invalidate ();
			animDisplay.BackgroundImage = anim.updateAnim (animEnum.WALK).image;
			Application.Run(animDisplay);
		}

		private static void updateImage(object sender, EventArgs e)
		{
			animDisplay.BackgroundImage = anim.updateAnim (state).image;
			animDisplay.BackgroundImageLayout = ImageLayout.Stretch;
		}

		private static void updateState(object sender, EventArgs e)
		{
			switch((int)state)
			{
			case (int)animEnum.IDLE:
				state = animEnum.WALK;
				break;
			case (int)animEnum.WALK:
				state = animEnum.JUMP;
				break;
			case (int)animEnum.JUMP:
				state = animEnum.TUCK;				
				break;
			case (int)animEnum.TUCK:
				state = animEnum.LAND;
				break;
			case (int)animEnum.LAND:
				state = animEnum.CROUCH;
				break;
			case (int)animEnum.CROUCH:
				state = animEnum.DIE;
				break;
			case (int)animEnum.DIE:
				state = animEnum.IDLE;
				break;
			}
			state = animEnum.TUCK;
		}
	}
}

