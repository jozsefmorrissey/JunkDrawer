﻿using System;

namespace ContraClone
{
	public abstract class SceneObject
	{
		public physicsSturct phyStruct;

		public bool visible;
		public int layer;
		public double centerX;
		public double centerY;
		public int staticX;
		public int staticY;

		protected double lastX = 0;
		protected double lastY = 0;
		protected int refreshDist = 10;

		public abstract void calculatePosition (SceneObject focalPoint);
	}
}

