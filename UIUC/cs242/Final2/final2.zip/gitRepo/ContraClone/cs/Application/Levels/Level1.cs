﻿using System;
using System.Drawing;

namespace ContraClone
{
	public class Level1
	{
		//public abstract class BarriorBuilder{};

		public static void init(ref sceneInfo info)
		{
			staticProperties (ref info);
		}

		private static void staticProperties(ref sceneInfo info){
			String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/level1.png";
			Image background = (Bitmap)Image.FromFile (imagePath, true);

			info.hero = new Character (200, 0, "hero");
			info.view_target = info.hero;
			info.barriorTolerance = 10;

			Physics.initPysics ((int)timeEnum.CONTROL_REFRESH);

			info.objects [info.characterCount++] = info.hero;

			info.levelCount = 7;
			info.barriors = new Barrior[info.levelCount] [];
			createBarriors (ref info);

			info.background = new Background (background, Init.window);
			info.background.calculatePosition (info.view_target);
			info.backgrounds [info.backgrounds.Length - 1] = info.background;
		}
	
		private static void createBarriors(ref sceneInfo info)
		{
			info.barriors [0] = new Barrior[3];
			info.barriors [0] [info.barriorCounts[0]++] = new Barrior(5390, 295, 7395, 295, true, false, true, false);
			info.barriors [0] [info.barriorCounts[0]++] = new Barrior(8020, 295, 8650, 295, true, false, true, false);
			info.barriors [0] [info.barriorCounts[0]++] = new Barrior(10280, 295, 10530, 295, true, false, true, false);

			info.barriors [1] = new Barrior [18];
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(12290, 420, 12790, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(10660, 420, 10910, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(10155, 420, 10405, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(9280, 420, 9525, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(8775, 420, 9025, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(7275, 420, 8150, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(4635, 420, 5640, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(4510, 420, 4635, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(4385, 420, 4510, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(4260, 420, 4385, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(4130, 420, 4260, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(3505, 420, 4130, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(3380, 420, 3505, 420, true, false, false, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(3380, 420, 3505, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(3260, 420, 3380, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(3130, 420, 3260, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(3000, 420, 3130, 420, true, false, true, false);
			info.barriors [1] [info.barriorCounts[1]++] = new Barrior(115, 420, 3000, 420, true, false, true, false);

			info.barriors [2] = new Barrior [9];
			info.barriors [2] [info.barriorCounts[2]++] = new Barrior(620, 545, 995, 545, true, false, true, false);
			info.barriors [2] [info.barriorCounts[2]++] = new Barrior(1625, 545, 1870, 545, true, false, true, false);
			info.barriors [2] [info.barriorCounts[2]++] = new Barrior(6263, 547, 7139, 547, true, false, true, false);
			info.barriors [2] [info.barriorCounts[2]++] = new Barrior(8525, 545, 8900, 545, true, false, true, false);
			info.barriors [2] [info.barriorCounts[2]++] = new Barrior(9155, 545, 9405, 545, true, false, true, false);
			info.barriors [2] [info.barriorCounts[2]++] = new Barrior(9655, 545, 9905, 545, true, false, true, false);
			info.barriors [2] [info.barriorCounts[2]++] = new Barrior(10785, 545, 11410, 545, true, false, true, false);
			info.barriors [2] [info.barriorCounts[2]++] = new Barrior(12040, 545, 12285, 545, true, false, true, false);
			info.barriors [2] [info.barriorCounts[2]++] = new Barrior(12790, 545, 12915, 545, true, false, true, false);

			info.barriors [3] = new Barrior [5];
			info.barriors [3] [info.barriorCounts[3]++] = new Barrior(12415, 610, 12790, 610, true, false, true, false);
			info.barriors [3] [info.barriorCounts[3]++] = new Barrior(10410, 610, 10530, 610, true, false, true, false);
			info.barriors [3] [info.barriorCounts[3]++] = new Barrior(8275, 610, 8400, 610, true, false, true, false);
			info.barriors [3] [info.barriorCounts[3]++] = new Barrior(5890, 610, 6140, 610, true, false, true, false);
			info.barriors [3] [info.barriorCounts[3]++] = new Barrior(2500, 610, 2875, 610, true, false, true, false);

			info.barriors [4] = new Barrior [7];
			info.barriors [4] [info.barriorCounts[4]++] = new Barrior(995, 675, 1120, 675, true, false, true, false);
			info.barriors [4] [info.barriorCounts[4]++] = new Barrior(1375, 675, 1495, 675, true, false, true, false);
			info.barriors [4] [info.barriorCounts[4]++] = new Barrior(7520, 675, 7775, 675, true, false, false, false);
			info.barriors [4] [info.barriorCounts[4]++] = new Barrior(7900, 675, 8150, 675, true, false, false, false);
			info.barriors [4] [info.barriorCounts[4]++] = new Barrior(9780, 675, 10155, 675, true, false, false, false);
			info.barriors [4] [info.barriorCounts[4]++] = new Barrior(11660, 675, 11910, 675, true, false, false, false);
			info.barriors [4] [info.barriorCounts[4]++] = new Barrior(12915, 675, 13040, 675, true, false, true, false);

			info.barriors [5] = new Barrior [10];
			info.barriors [5] [info.barriorCounts[5]++] = new Barrior(12290, 800, 13528, 800, true, false, false, false);
			info.barriors [5] [info.barriorCounts[5]++] = new Barrior(11163, 800, 11533, 800, true, false, false, false);
			info.barriors [5] [info.barriorCounts[5]++] = new Barrior(10283, 800, 10408, 800, true, false, false, false);
			info.barriors [5] [info.barriorCounts[5]++] = new Barrior(9658, 800, 9778, 800, true, false, false, false);
			info.barriors [5] [info.barriorCounts[5]++] = new Barrior(9153, 800, 9183, 800, true, false, false, false);
			info.barriors [5] [info.barriorCounts[5]++] = new Barrior(6773, 800, 7523, 800, true, false, false, false);
			info.barriors [5] [info.barriorCounts[5]++] = new Barrior(5518, 800, 5888, 800, true, false, false, false);
			info.barriors [5] [info.barriorCounts[5]++] = new Barrior(2378, 800, 2623, 800, true, false, false, false);
			info.barriors [5] [info.barriorCounts[5]++] = new Barrior(1123, 800, 1368, 800, true, false, false, false);

			info.barriors [6] = new Barrior [6];
			info.barriors [6] [info.barriorCounts[6]++] = new Barrior(5, 840, 6935, 840, true, true, false, false);
		}	
	}
}

