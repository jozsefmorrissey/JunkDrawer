﻿using System;
using System.Drawing;
using System.Reflection;

namespace ContraClone
{
	public static class BarriorBuilder
	{
		public static void barriorBuilder (ref sceneInfo info)
		{
			level1(ref info);
			/*Level1 lvl1 = new Level1();
			Type t =lvl1.GetType();
			//ref sceneInfo iks = info;
			object[] i = new object[]{ info };
			t.GetMethod ("staticProperties").Invoke(null, i);*/

		}

		public static void level1(ref sceneInfo info)
		{
			String imagePath = System.IO.Directory.GetCurrentDirectory () + "/../../Images/level1.png";
			Image background = (Bitmap)Image.FromFile (imagePath, true);

			info.hero = new Character (5, 5, "target");
			info.view_target = info.hero;

			Physics.initPysics ((int)timeEnum.CONTROL_REFRESH);

			info.objects [info.characterCount++] = info.hero;


			info.background = new Background (background, Init.window);
			info.background.calculatePosition (info.view_target);
			info.backgrounds [info.backgrounds.Length - 1] = info.background;
		}
	}
}

