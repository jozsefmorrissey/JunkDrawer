﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;


namespace ContraClone
{
	public class GameControl
	{
		private static bool[] keysDown;
		private static Keys[] keys;
		private static bool[] keysProcessed;
		private static double savedX;
		private static double savedY;

		public static void initControls()
		{
			keys = new []{Keys.Right, Keys.Left, Keys.Up, Keys.Down, Keys.Space, Keys.Enter, 
				Keys.A, Keys.D, Keys.P, Keys.C, Keys.W, Keys.G, Keys.B, Keys.L, Keys.K};
			keysDown = new bool[keys.Length];
			keysProcessed = new bool[keysDown.Length];
		}

		public static void keyTimerCallback(object sender, EventArgs e)
		{
			for (int index = 0; index < keysDown.Length; index++) 
			{
				if (keysDown [index]) 
				{
					gamePlayKeyPress (index);
				}
			}
			Init.scene.info.hero.phyStruct = Physics.calculateFinalPosition (Init.scene.info.hero.phyStruct, Init.scene.info.hero.currentPlatform != null);
			Init.scene.gravity ();
			Init.window.Invalidate ();
		}

		public static void keyDownEvent(object sender, KeyEventArgs e)
		{

			for (int index = 0; index < keysDown.Length; index++)
			{
				if(e.KeyCode == keys[index])
				{
					keysDown[index] = true;
				}
			}
		}

		public static void keyUpEvent(object sender, KeyEventArgs e)
		{
			for (int index = 0; index < keysDown.Length; index++)
			{
				if(e.KeyCode == keys[index])
				{
					keysDown[index] = false;
					keysProcessed [index] = false;
				}
			}
		}

		//TODO: Figure out a non-delayed key detection method.
		// Detect all keys used during game play.
		protected static void gamePlayKeyPress(int keyIndex)
		{
			int movementOffset = 200;
			int jumpForce = 50000;
			switch (keyIndex)
			{
				case (int)keyEnum.RIGHT:
					Init.scene.updateGraphics (movementOffset, 0);
					break;
				case (int)keyEnum.LEFT:
					Init.scene.updateGraphics (-movementOffset, 0);
					break;
				case (int)keyEnum.UP:
					Init.scene.updateGraphics (0, -jumpForce);
					break;
				case (int)keyEnum.DOWN:
					Init.scene.dropDown();
					break;
				case (int)keyEnum.SPACE:
					Init.scene.updateGraphics (0, -movementOffset);
					break;
				case (int)keyEnum.ENTER:
					savedX = Init.scene.info.view_target.phyStruct.positionX;
					savedY = Init.scene.info.view_target.phyStruct.positionY;
					break;
				case (int)keyEnum.L:
					Init.scene.info.view_target.phyStruct.positionX = savedX;
					Init.scene.info.view_target.phyStruct.positionY = savedY;
					break;
			}
		}
	}
}

