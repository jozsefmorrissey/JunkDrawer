using System;
using System.Windows.Forms;
using System.Drawing;
//using Gtk;




namespace ContraClone
{
	public static class Init
	{
		public static Window window;
		public static Scene scene;

		private static bool tests = false;
		public static bool barriorBuilder = false;
		private static bool controlsInit = false;

		static int Main(string[] args)
		{
			if (tests) {
				runTests();
				return 0;
			}
			
			window = new Window ();
			scene = new Scene (window);
			if (!controlsInit && !barriorBuilder)
				GameControl.initControls ();
			else if (!controlsInit)
				BarriorBuilderControl.initControls ();
 
			// Display the form as a modal dialog box.
			Application.Run(window);
			//window.Show();
			return 0;
		}

		private static void runTests()
		{
			//TestClass.testAll ();
			//AnimationTests.loadImages();
			PhysicsTests.TestGravity();
			//PhysicsTests.testHorizontalMovementPhysics();
		}
	}
}
