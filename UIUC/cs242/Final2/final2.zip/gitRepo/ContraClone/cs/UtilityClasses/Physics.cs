﻿using System;

namespace ContraClone
{
	public struct physicsSturct{
		public double forceY;
		public double positionY;
		public double velocityY;

		public double forceX;
		public double positionX;
		public double velocityX;

		public double mass;
	}

	public static class Physics
	{
		// Constants used to simulate the fact that opposing forces increase with velocity.
		private static double kHorizontal = 2.8;
		private static double kVerical = 1.6;
		private static double gravity;
		private static double timeElapsed;
		private static double pixelsToMeters = 25;
		private static double runCoeficient = 100;

		// Refresh rate is in milliseconds.
		public static void initPysics(double refreshRate){
			timeElapsed = refreshRate / 1000;
			gravity = 19.8;
		}

		// The average runner can reach 90% of thier maximum velocity (approx. 16 mph) in about 1.8 seconds 
		// The coeficient kHorizontal multplied by velocity cubed mimics this relationship.
		public static double forceHorizontal(double force, double velocity, double mass){
			if((force > 0 && velocity < 0) || (force < 0 && velocity > 0))
				return force * 10;
			return force + (kHorizontal * velocity * velocity)*(velocity > 0 ?  -1 : 1);
		}

		public static double forceVertical(double force, double velocity, double mass){
			double noAirResist = force + (velocity * mass) + mass * gravity;
			return noAirResist > 0 ? noAirResist - (kVerical * velocity * velocity) : noAirResist + (kVerical * velocity * velocity);
		}

		public static void calculateFinalPositionHorizontal(physicsSturct initial, ref physicsSturct final){
			double totalForce = forceHorizontal (initial.forceX, initial.velocityX, initial.mass);
			calculateFinalPositionX (initial.velocityX, initial.positionX, initial.mass, totalForce, ref final);
		}

		public static void calculateFinalPositionVertical(physicsSturct initial, ref physicsSturct final){
			double totalForce = forceVertical (initial.forceY, initial.velocityY, initial.mass);
			calculateFinalPositionY (initial.velocityY, initial.positionY, initial.mass, totalForce, ref final);
		}

		private static void calculateFinalPositionX(double velocity, double position, double mass, double force, ref physicsSturct final){
			final.velocityX = (velocity + force * timeElapsed / mass);
			final.positionX = position + ((final.velocityX) * timeElapsed) * runCoeficient;
			final.forceX = 0;
		}

		private static void calculateFinalPositionY(double velocity, double position, double mass, double force, ref physicsSturct final){
			final.velocityY = velocity + force * timeElapsed / mass;
			final.positionY = position + ((final.velocityY + velocity) * timeElapsed / (2)) * pixelsToMeters;
			final.forceY = 0;
		}

		public static physicsSturct calculateFinalPosition(physicsSturct initial, bool grounded){
			physicsSturct final = new physicsSturct ();
			if(initial.forceX != 0)
				calculateFinalPositionHorizontal (initial, ref final);
			else{
				initial.velocityX = final.forceX = 0;
				final.positionX = initial.positionX;
			}
			if (!grounded)
				calculateFinalPositionVertical (initial, ref final);
			else{
				initial.velocityY = final.forceY = 0;
				final.positionY = initial.positionY;
			}
			final.mass = initial.mass;
			return final;
		}
	}
}

