package Enums;

public enum PartCatagory {
	SUSPENSION, DRIVE_TRAIN, POWER_TRAIN, BRAKES, FUEL, ELECTRICAL,
	IGNITION,
	
	STORAGE,
}
