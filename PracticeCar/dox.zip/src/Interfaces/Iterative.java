package Interfaces;


import Enums.Location;

public interface Iterative {
	public void create(String className, Location locs);

}
