package Interfaces;

public interface Electronic {
	public boolean turnOn();	
	public boolean turnOff();	
	public boolean run();
}
