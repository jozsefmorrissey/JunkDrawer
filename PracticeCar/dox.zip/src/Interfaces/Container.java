package Interfaces;

public interface Container {
		public String checkLevel();
		public double getCapacity();
		public void topOff();
		public void replaceContents();
		public double getLastFlush();
}
