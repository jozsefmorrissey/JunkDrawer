package Cars;

import IgnitionParts.Computer;
import IgnitionParts.Starter;
import Systems.Electrical;

public class Simulator {
	public static void main(String[] args){
		drainBatteryWithStarter();
		alternatorTest();
	}
	
	private static void monitorGas(Car c){
		
		while(c.getBattery().operational() || c.getMotor().operational()){
			System.out.println("\nFuel level " + c.getTank().checkLevel() + ".");
			System.out.println("Battery level " + c.getBattery().getPercent()*100 + "%.\n");
			System.out.println(c.getMotor().isRunning());
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void alternatorTest(){
		Car c = new Car();
		System.out.println("Alternator test starting");

		c.getTank().drain(11.9);
		c.getBattery().drain(90);
		c.inspect();

		monitorGas(c);
		
	}
	
	public static void drainBatteryWithStarter(){
		Car c = new Car();
		System.out.println("Starter drain starting");
		c.getTank().drain(12);
		c.getBattery().drain(98);
		c.inspect();

		Starter s = c.getStarter();
		s.turnOn();
		monitorGas(c);
	}
}
