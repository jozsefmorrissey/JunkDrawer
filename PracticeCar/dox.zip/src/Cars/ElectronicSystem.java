package Cars;

import ElectricalParts.Battery;
import Enums.Location;
import Enums.Status;

public abstract class ElectronicSystem implements Interfaces.Electronic, Interfaces.System{
	private Car car;
	private boolean exit = false;
	private double sleepTime = 100;
	
	public ElectronicSystem(){}
	
	public ElectronicSystem(Car c, Location loc){
		car = c;
	}	
	
	public abstract Battery getBattery();
	
	public boolean turnOn(){

		if(getBattery() == null || getBattery().getStatus() == Status.BROKEN)
			return false;

	    WorkerThread runner = new WorkerThread(this);        
	    Thread thread = new Thread(runner);
	    thread.start();
	    
		return true;
	}
	
	public boolean turnOff(){
		exit = true;
		return true;
	}
	
	public abstract boolean operationLoop();	
	
	@Override
	public boolean run() {
		while(keepGoing()){
			if(this.operational()){
				operationLoop();
				ElectronicSystem.sleep(sleepTime);
			}
			else
				this.turnOff();
		}
		return false;
	}
	
	public boolean keepGoing(){return !exit;}
	
	public static Boolean sleep(double milSec){
		try {
			Thread.sleep((long) milSec);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean setSleepTime(double st){
		if(st > 0){
			sleepTime = st;
			return true;
		}
		return false;
	}
	
	public Car getCar(){return car;}
}
